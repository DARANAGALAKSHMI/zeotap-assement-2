export interface Message {
  id: string;
  content: string;
  type: 'user' | 'bot';
  timestamp: Date;
}

export interface CDPPlatform {
  name: string;
  docs: string;
  color: string;
}

export interface SearchResult {
  platform: string;
  content: string;
  relevance: number;
}