import Fuse from 'fuse.js';
import { marked } from 'marked';
import { knowledgeBase, platforms } from '../data/cdpData';
import { SearchResult } from '../types';
import { fetchDocumentation } from './docFetcher';

const fuseOptions = {
  includeScore: true,
  threshold: 0.6,
  keys: ['content']
};

const searchDocs = async (query: string): Promise<SearchResult[]> => {
  // First, search local knowledge base
  const documents = Object.entries(knowledgeBase).map(([key, content]) => ({
    id: key,
    content,
    platform: key.split('-')[0]
  }));

  const fuse = new Fuse(documents, fuseOptions);
  const localResults = fuse.search(query);

  // Then, fetch relevant documentation from platforms
  const platformResults = await Promise.all(
    platforms.map(async platform => {
      const sections = await fetchDocumentation(platform.name.toLowerCase(), query);
      return sections.map(section => ({
        platform: platform.name.toLowerCase(),
        content: section.content,
        relevance: 0.8 // Default relevance for fresh documentation
      }));
    })
  );

  // Combine and sort results
  const allResults = [
    ...localResults.map(result => ({
      platform: result.item.platform,
      content: result.item.content,
      relevance: 1 - (result.score || 0)
    })),
    ...platformResults.flat()
  ];

  // Remove duplicates and sort by relevance
  const uniqueResults = allResults.reduce((acc: SearchResult[], current) => {
    const exists = acc.some(item => item.content === current.content);
    if (!exists) {
      acc.push(current);
    }
    return acc;
  }, []);

  return uniqueResults.sort((a, b) => b.relevance - a.relevance);
};

const isRelevantQuestion = (query: string): boolean => {
  const cdpKeywords = ['segment', 'mparticle', 'lytics', 'zeotap', 'cdp', 'data', 'integration', 'source', 'audience'];
  const lowercaseQuery = query.toLowerCase();
  return cdpKeywords.some(keyword => lowercaseQuery.includes(keyword));
};

export const generateResponse = async (query: string): Promise<string> => {
  if (!isRelevantQuestion(query)) {
    return "I'm specifically trained to help with CDP-related questions about Segment, mParticle, Lytics, and Zeotap. Could you please ask something related to these platforms?";
  }

  const results = await searchDocs(query);
  
  if (results.length === 0) {
    return "I couldn't find a specific answer to your question. Please try rephrasing or ask about a different CDP-related topic.";
  }

  const bestMatch = results[0];
  const response = marked(bestMatch.content);
  
  return response;
};