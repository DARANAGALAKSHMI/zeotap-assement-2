import { platforms } from '../data/cdpData';

interface DocSection {
  title: string;
  content: string;
  url: string;
  platform: string;
}

// Simulated documentation sections for each platform
const mockDocSections: Record<string, DocSection[]> = {
  segment: [{
    title: 'Setting up Sources',
    content: 'To set up a new source in Segment:\n1. Navigate to Connections > Sources\n2. Click "Add Source"\n3. Choose your source type\n4. Configure the source settings\n5. Enable the source',
    url: 'https://segment.com/docs/connections/sources/',
    platform: 'segment'
  }],
  mparticle: [{
    title: 'User Profiles',
    content: 'To create a user profile in mParticle:\n1. Use the Identity API\n2. Send user attributes\n3. Configure identity mapping\n4. Verify profile creation',
    url: 'https://docs.mparticle.com/guides/identity/',
    platform: 'mparticle'
  }],
  lytics: [{
    title: 'Audience Building',
    content: 'To build an audience segment in Lytics:\n1. Go to Audiences\n2. Click "Create New Audience"\n3. Define segment criteria\n4. Set behavioral rules\n5. Save and activate',
    url: 'https://docs.lytics.com/audiences/',
    platform: 'lytics'
  }],
  zeotap: [{
    title: 'Data Integration',
    content: 'To integrate data with Zeotap:\n1. Access the Integration Hub\n2. Select data source\n3. Configure connection settings\n4. Map data fields\n5. Test and validate',
    url: 'https://docs.zeotap.com/integrations/',
    platform: 'zeotap'
  }]
};

export async function fetchDocumentation(platform: string, query: string): Promise<DocSection[]> {
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 300));
  
  // Return mock documentation for the platform
  return mockDocSections[platform] || [];
}