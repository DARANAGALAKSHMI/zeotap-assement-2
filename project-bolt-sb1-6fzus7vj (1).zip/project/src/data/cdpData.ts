import { CDPPlatform } from '../types';

export const platforms: CDPPlatform[] = [
  {
    name: 'Segment',
    docs: 'https://segment.com/docs/?ref=nav',
    color: '#52BD95'
  },
  {
    name: 'mParticle',
    docs: 'https://docs.mparticle.com/',
    color: '#FF6B6C'
  },
  {
    name: 'Lytics',
    docs: 'https://docs.lytics.com/',
    color: '#4A90E2'
  },
  {
    name: 'Zeotap',
    docs: 'https://docs.zeotap.com/home/en-us/',
    color: '#7C5DFA'
  }
];

// Sample knowledge base - In a real app, this would be much more extensive
export const knowledgeBase = {
  'segment-source': `To set up a new source in Segment:
1. Navigate to Connections > Sources
2. Click "Add Source"
3. Choose your source type
4. Configure the source settings
5. Enable the source`,
  
  'mparticle-profile': `To create a user profile in mParticle:
1. Use the Identity API
2. Send user attributes
3. Configure identity mapping
4. Verify profile creation`,
  
  'lytics-audience': `To build an audience segment in Lytics:
1. Go to Audiences
2. Click "Create New Audience"
3. Define segment criteria
4. Set behavioral rules
5. Save and activate`,
  
  'zeotap-integration': `To integrate data with Zeotap:
1. Access the Integration Hub
2. Select data source
3. Configure connection settings
4. Map data fields
5. Test and validate`,
};